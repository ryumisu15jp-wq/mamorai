import { useMemo, useState } from 'react'
import {
  applyTemplateConfig,
  resolveForm,
  type ResolvedForm,
  type SectionDef,
  type TemplateConfig,
} from '@mamorai/input-core'
import { demoTemplate } from '../report/demoData.js'

// [REQ-024] テンプレート設定によるセクション ON/OFF。
// セクションの有効化反映（applyTemplateConfig）とフォーム解決（resolveForm）は
// @mamorai/input-core に委譲する（ON/OFF 適用を UI で再実装しない＝層分離厳守）。

const KIND_LABEL: Record<SectionDef['kind'], string> = {
  meta: 'meta',
  table: 'table',
  counter: 'counter',
  check: 'check',
  gate: 'gate',
}

export function TemplateSettings(): JSX.Element {
  const template = useMemo(() => demoTemplate(), [])

  // OFF にしたセクション ID の集合（UI 状態）。判定・適用は input-core。
  const [disabled, setDisabled] = useState<Set<string>>(() => new Set())

  const config = useMemo<TemplateConfig>(
    () => ({ siteId: template.siteId, disabledSectionIds: [...disabled] }),
    [template.siteId, disabled],
  )

  // [input-core] applyTemplateConfig: 非破壊で enabled=false を付与した新テンプレート
  const applied = useMemo(() => applyTemplateConfig(template, config), [template, config])
  // [input-core] resolveForm: enabled!==false のセクションだけの描画用フォーム
  const form: ResolvedForm = useMemo(() => resolveForm(applied), [applied])
  const visibleIds = useMemo(() => new Set(form.sections.map((s) => s.id)), [form])

  const toggle = (id: string): void => {
    setDisabled((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  return (
    <div className="page">
      <header className="page-head">
        <h1 className="page-title">テンプレート設定</h1>
        <span className="muted">
          {template.name} / ON/OFF 反映は @mamorai/input-core
        </span>
      </header>

      <p className="tpl-note">
        セクションを OFF にすると日報入力フォームから即時に消えます。
        <strong> 過去の日報データ・集計は変更されません</strong>（非破壊。applyTemplateConfig は元テンプレートを複製します）。
      </p>

      {/* セクション ON/OFF トグル */}
      <section className="card" aria-label="セクション設定">
        <div className="card-h">
          <h2>セクション ON / OFF</h2>
        </div>
        <div className="card-b">
          {template.sections.map((s) => {
            const on = !disabled.has(s.id)
            return (
              <div key={s.id} className="tpl-toggle-row">
                <div className="tpl-toggle-info">
                  <span className={`badge badge-${s.kind}`}>{KIND_LABEL[s.kind]}</span>
                  <span className="tpl-toggle-label">{s.label}</span>
                  <span className="muted">（{s.fields.length} 項目）</span>
                </div>
                <button
                  type="button"
                  className={`switch${on ? ' switch-on' : ''}`}
                  role="switch"
                  aria-checked={on}
                  aria-label={`${s.label} を${on ? 'OFFにする' : 'ONにする'}`}
                  onClick={() => toggle(s.id)}
                >
                  <span className="switch-knob" />
                  <span className="switch-text">{on ? 'ON' : 'OFF'}</span>
                </button>
              </div>
            )
          })}
        </div>
      </section>

      {/* 入力フォームプレビュー（OFF セクションが消えることを即時表示） */}
      <section className="card" aria-label="入力フォームプレビュー">
        <div className="card-h">
          <h2>日報入力フォーム プレビュー（resolveForm 結果）</h2>
        </div>
        <div className="card-b">
          {template.sections.map((s) => {
            const shown = visibleIds.has(s.id)
            return (
              <div key={s.id} className={`tpl-preview-section${shown ? '' : ' tpl-hidden'}`}>
                <div className="tpl-preview-head">
                  <span className={`badge badge-${s.kind}`}>{KIND_LABEL[s.kind]}</span>
                  <strong>{s.label}</strong>
                  {!shown && <span className="status st-missing">非表示</span>}
                </div>
                {shown && (
                  <ul className="tpl-preview-fields">
                    {s.fields.map((f) => (
                      <li key={f.key}>
                        {f.label}
                        <span className="muted"> ({f.type})</span>
                        {f.required && <span className="req">必須</span>}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )
          })}
          <p className="muted">
            表示中セクション: {form.sections.length} / {template.sections.length}
          </p>
        </div>
      </section>
    </div>
  )
}
