import { useState } from 'react'
import { QuickDailyReport } from './features/report/QuickDailyReport.js'
import { MonthlyReport } from './features/month/MonthlyReport.js'
import { ReportList } from './features/report/ReportList.js'
import { RiskRanking } from './features/risk/RiskRanking.js'
import { ShiftGrid } from './features/shift/ShiftGrid.js'
import { DailyAssignment } from './features/shift/DailyAssignment.js'
import { ConstraintEditor } from './features/shift/ConstraintEditor.js'
import { AiOptimizer } from './features/shift/AiOptimizer.js'
import { Notifications } from './features/notify/Notifications.js'
import { Education } from './features/training/Education.js'
import { TemplateSettings } from './features/template/TemplateSettings.js'
import { demoConstraints } from './features/shift/demoShift.js'
import type { ConstraintDef } from '@mamorai/input-core'

// MAMOR-AI デスクトップ MVP のシェル。
// WebView2 前提の PC 専用アプリ（Tauri v2 で dist/ をラップして配布）。
// 各画面の集計・ワークフロー・リスク・シフト最適化は @mamorai/input-core に委譲（層分離厳守）。

type Tab =
  | 'report'
  | 'month'
  | 'list'
  | 'risk'
  | 'shift'
  | 'assign'
  | 'constraint'
  | 'ai'
  | 'notify'
  | 'education'
  | 'template'

const TABS: { key: Tab; label: string }[] = [
  { key: 'report', label: '1分日報' },
  { key: 'month', label: '月報' },
  { key: 'list', label: '日報一覧' },
  { key: 'risk', label: 'リスク' },
  { key: 'shift', label: 'シフト' },
  { key: 'assign', label: '配置表' },
  { key: 'constraint', label: '制約' },
  { key: 'ai', label: 'AIシフト' },
  { key: 'notify', label: '通知' },
  { key: 'education', label: '教育' },
  { key: 'template', label: 'テンプレ設定' },
]

export function App(): JSX.Element {
  const [tab, setTab] = useState<Tab>('report')
  // 制約は「制約」タブと「AIシフト」タブで共有する（NL構造化→エディタ反映を体現）。
  const [constraints, setConstraints] = useState<ConstraintDef[]>(() => demoConstraints())

  return (
    <div className="app-shell">
      <nav className="app-nav" aria-label="サイドナビ">
        <div className="app-logo">MAMOR-AI</div>
        {TABS.map((t) => (
          <button
            key={t.key}
            type="button"
            className={`nav-item${tab === t.key ? ' active' : ''}`}
            aria-current={tab === t.key ? 'page' : undefined}
            onClick={() => setTab(t.key)}
          >
            {t.label}
          </button>
        ))}
        <span className="nav-note">Sprint4 / 通知・教育・テンプレ設定・Tauri統合は @mamorai/input-core</span>
      </nav>
      <main className="app-main" id="main">
        {tab === 'report' && <QuickDailyReport />}
        {tab === 'month' && <MonthlyReport />}
        {tab === 'list' && <ReportList />}
        {tab === 'risk' && <RiskRanking />}
        {tab === 'shift' && <ShiftGrid />}
        {tab === 'assign' && <DailyAssignment />}
        {tab === 'constraint' && <ConstraintEditor constraints={constraints} onChange={setConstraints} />}
        {tab === 'ai' && <AiOptimizer constraints={constraints} onChange={setConstraints} />}
        {tab === 'notify' && <Notifications />}
        {tab === 'education' && <Education />}
        {tab === 'template' && <TemplateSettings />}
      </main>
    </div>
  )
}
