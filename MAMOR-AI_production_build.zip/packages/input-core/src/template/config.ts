// [REQ-024] テンプレートのセクションON/OFF適用（非破壊・過去集計に影響しない）
import type { ReportTemplate, TemplateConfig } from '../types.js'

/**
 * [REQ-024] disabledSectionIds のセクションのみ enabled=false にした新 ReportTemplate を返す。
 * 元 template・元 section オブジェクトは不変（非破壊コピー）。存在しない ID は無視。
 */
export function applyTemplateConfig(
  template: ReportTemplate,
  config: TemplateConfig,
): ReportTemplate {
  const disabled = new Set(config.disabledSectionIds)
  const sections = template.sections.map((s) =>
    disabled.has(s.id) ? { ...s, enabled: false } : { ...s },
  )
  return { ...template, sections }
}
